package android.content;

import android.content.res.Resources;


public class Context {
    private Resources resources=new Resources();
    public Resources getResources() {
        return resources;
    }

    public String getPackageName() {
        return "";
    }
}

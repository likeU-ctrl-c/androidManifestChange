package android.text;

import org.apache.commons.lang3.StringUtils;


public class TextUtils extends StringUtils{

}

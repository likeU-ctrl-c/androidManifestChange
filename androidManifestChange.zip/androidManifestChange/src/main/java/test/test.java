package test;

import mageAndroidManifest.xslt;
import org.xmlpull.v1.XmlPullParserException;
import xml2axml.AxmlUtils;

import java.io.*;

public class test {
    public static void main(String[] args) throws Exception {
        bin2xml();
        megeAndroidManifest();
        xml2bin();
//        bin2xml2();


//        xml2bin2();
    }



    public static void megeAndroidManifest() throws Exception {
        //        配置文件
        File xslFile = new File("C:\\Users\\Administrator\\Downloads\\androidManifestChange\\src\\main\\java\\mageAndroidManifest\\manifestTemplate.xsl");
//        合并文件
        File configXml = new File("C:\\Users\\Administrator\\Desktop\\123123213\\test\\2222\\AndroidManifest2.xml");
//        原始的文件
        File finalConfigXml = new File("C:\\Users\\Administrator\\Downloads\\androidManifestChange\\src\\main\\java\\mageAndroidManifest\\manifest.xml");
//        结果文件
        File finalResXml = new File("C:\\Users\\Administrator\\Downloads\\androidManifestChange\\src\\main\\java\\mageAndroidManifest\\res.xml");

        xslt xs =xslt.getInstance();
        xs.Use(xslFile,configXml,finalConfigXml,finalResXml);
    }

    public static  void xml2bin() throws IOException, XmlPullParserException {
        String in2 = "C:\\Users\\Administrator\\Downloads\\androidManifestChange\\src\\main\\java\\mageAndroidManifest\\res.xml";
        String out2 = "C:\\Users\\Administrator\\Desktop\\123123213\\test\\2222\\AndroidManifest.xml";

        AxmlUtils.encode(in2, out2);
    }

    public static void bin2xml() throws FileNotFoundException {
        String in = "C:\\Users\\Administrator\\Desktop\\123123213\\test\\2222\\AndroidManifest.xml";
        String out = "C:\\Users\\Administrator\\Desktop\\123123213\\test\\2222\\AndroidManifest2.xml";
        AxmlUtils.decode(in, out);
    }

    public static void bin2xml2() throws FileNotFoundException {
        String in = "C:\\Users\\Administrator\\Desktop\\123123213\\test\\2222\\AndroidManifest.xml";
        String out = "C:\\Users\\Administrator\\Desktop\\123123213\\test\\2222\\AndroidManifest3.xml";
        AxmlUtils.decode(in, out);
    }

    public static  void xml2bin2() throws IOException, XmlPullParserException {
        String in2 = "C:\\Users\\Administrator\\Desktop\\123123213\\test\\2222\\AndroidManifest2.xml";
        String out2 = "C:\\Users\\Administrator\\Desktop\\123123213\\test\\2222\\AndroidManifest.xml";

        AxmlUtils.encode(in2, out2);
    }


}

package xml2axml;

import xml2axml.chunks.ValueChunk;


public interface ReferenceResolver {
    int resolve(ValueChunk value, String ref);
}

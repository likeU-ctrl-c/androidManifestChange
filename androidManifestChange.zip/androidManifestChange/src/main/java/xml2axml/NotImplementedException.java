package xml2axml;


public class NotImplementedException extends RuntimeException {
}

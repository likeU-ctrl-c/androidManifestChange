package xml2axml.test;


import org.xmlpull.v1.XmlPullParserException;
import xml2axml.AxmlUtils;

import java.io.IOException;


public class Main {
    public static void main(String args[]) throws IOException, XmlPullParserException {

        String in = "C:\\Users\\Administrator\\Desktop\\123123213\\test\\tesManifest\\AndroidManifest.xml";
        String out = "C:\\Users\\Administrator\\Desktop\\123123213\\test\\tesManifest\\AndroidManifest2.xml";
        AxmlUtils.decode(in, out);

        String in2 = "C:\\Users\\Administrator\\Desktop\\123123213\\test\\tesManifest\\AndroidManifest2.xml";
        String out2 = "C:\\Users\\Administrator\\Desktop\\123123213\\test\\tesManifest\\AndroidManifest3.xml";

        AxmlUtils.encode(in2, out2);

        String in3 = "C:\\Users\\Administrator\\Desktop\\123123213\\test\\tesManifest\\AndroidManifest3.xml";
        String out3 = "C:\\Users\\Administrator\\Desktop\\123123213\\test\\tesManifest\\AndroidManifest4.xml";

        AxmlUtils.decode(in3, out3);
    }


}
